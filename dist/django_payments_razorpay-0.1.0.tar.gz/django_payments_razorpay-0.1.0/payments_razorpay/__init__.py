# payments_razorpay/__init__.py

from .razorpay_provider import RazorpayProvider

__all__ = ['RazorpayProvider']

